<?php
namespace App\Exceptions;

class CouponException extends \Exception
{

}
?>